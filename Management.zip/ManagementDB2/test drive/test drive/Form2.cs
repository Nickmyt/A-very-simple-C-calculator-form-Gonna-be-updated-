﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test_drive
{
    public partial class Form2 : Form
    {
        private readonly String _connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=database.mdb;User Id=admin;Password=;";
        private OleDbConnection _conn;
        

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                //Define connection string.
                _conn = new OleDbConnection(_connectionString);
            }

            //Else cath the error and warn the user.
            catch (Exception exception)
            {
                MessageBox.Show(@"Database not found!" + exception);
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            
            _conn.ConnectionString = _connectionString;
            //,AnswerA,AnswerB,AnswerC,CorrectAnswer
            const String sqlQuery = "INSERT INTO MC_test(Question,AnswerA,AnswerB,AnswerC,CorrectAnswer) VALUES(@Question,@AnswerA,@AnswerB,@AnswerC,@CorrectAnswer)";
            var cmd = new OleDbCommand(sqlQuery, _conn);

            //Add params
            cmd.Parameters.AddWithValue("@Question", QuestionTB.Text);
            cmd.Parameters.AddWithValue("@AnswerA", Answer_A.Text);
            cmd.Parameters.AddWithValue("@AnswerB", Answer_B.Text);
            cmd.Parameters.AddWithValue("@AnswerC", Answer_C.Text);
            cmd.Parameters.AddWithValue("@CorrectAnswer", Correct_Answer.Text);


            //Execute the query if connection is succesfull.Else throw error message.
            try
            {
                _conn.Open();
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show(@"Successfully Inserted");
                }
                _conn.Close();
                ShuffleAnswers(QuestionTB.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                _conn.Close();
            }
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            //Gets you back to the Main Menu
            
           
            this.Close();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }

        //Function to shuffle answers inside db
        public void ShuffleAnswers(String question)
        {

            //sql query to select fields matching question
            String query = @"SELECT AnswerA,AnswerB,AnswerC,CorrectAnswer FROM MC_Test WHERE Question LIKE '"+question+"'"; 
            
            var cmd=new OleDbCommand(query,_conn);

            var answers=new List<string>();  //List to  add the answers


            try
            {
                //Connect and execute command.
                _conn.Open();
                OleDbDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    String ansA = reader.GetValue(0).ToString(); //AnswerA column value
                    String ansB = reader.GetValue(1).ToString(); //AnswerB column value
                    String ansC = reader.GetValue(2).ToString(); //AnswerC column value
                    String corrAns = reader.GetValue(3).ToString(); //CorrectAnswer column value

                    answers.Add(ansA);
                    answers.Add(ansB);
                    answers.Add(ansC);
                    answers.Add(corrAns);

                    MessageBox.Show(@"Answers Added !");
                    //Console.WriteLine(@"time = {0}, strike = {1}, vol = {2}", ansA, ansB, ansC,corrAns);
                }
                _conn.Close();
                Shuffle(answers);

               
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }


        public void Shuffle<T>(List<T> list)
        {
            var provider = new RNGCryptoServiceProvider();
            int n = list.Count;
            while (n > 1)
            {
                byte[] box = new byte[1];
                do provider.GetBytes(box);
                while (!(box[0] < n * (Byte.MaxValue / n)));
                int k = (box[0] % n);
                n--;
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
