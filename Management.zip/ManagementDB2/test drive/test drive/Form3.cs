﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test_drive
{
    public partial class Form3 : Form
    {
        private readonly String _connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=database.mdb;User Id=admin;Password=;";
        private  OleDbConnection _conn;
        private int n;

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            try
            {
                //Define connection string.
                _conn = new OleDbConnection(_connectionString);
            }

            //Else cath the error and warn the user.
            catch (Exception exception)
            {
                MessageBox.Show(@"Database not found!" + exception);
            }
            MakeQuiz();
        }

        private void MakeQuiz()
        {
            //Prints the Questions and the awnsers on a new form
            String query = "SELECT Question,AnswerA, AnswerB, AnswerC, CorrectAnswer FROM MC_Test";
            
            var answers=new List<String>();

            var cmd = new OleDbCommand(query, _conn);

            try
            {
                _conn.Open();

                var adapter = new OleDbDataAdapter(cmd);

                var dt = new DataTable();
                adapter.Fill(dt);

                n = dt.Rows.Count;
                _conn.Close();

                int x = 0, y = 50;

                var controls = new List<Control>();


                _conn.Open();
                OleDbDataReader reader = cmd.ExecuteReader();

                
                

                while (reader.Read())
                {
                    String quest = reader.GetValue(0).ToString(); //Question column value
                    String ansA = reader.GetValue(1).ToString(); //AnswerA column value
                    String ansB = reader.GetValue(2).ToString(); //AnswerB column value
                    String ansC = reader.GetValue(3).ToString(); //AnswerC column value
                    String corrAns = reader.GetValue(4).ToString() ; //CorrectAnswer column value
                    
                    var label = new Label();
                    label.Text = quest;
                    label.BackColor = Color.DarkKhaki;

                    label.Font = new Font("Arial", 16, FontStyle.Underline);
                    label.Location = new Point(x, y);
                    controls.Add(label);
                    
                   answers.Add(ansA);
                   answers.Add(ansB);
                   answers.Add(ansC);
                   answers.Add(corrAns+".");

                   var f2 = new Form2();


                   f2.Shuffle(answers);

                  
                    
                   for (int j = 0; j < 4; j++)
                   {
                       var radioButton = new RadioButton(); //Shows the potential awnsers of he question , each time randomized
                       radioButton.Text = answers[j] ;
                        radioButton.Font = new Font("Perpetua", 14 , FontStyle.Regular);//Determines the font
                       radioButton.Location = new Point(x, y + 50);
                       controls.Add(radioButton);
                       y += 50;
                   }
                   y += 80;

                    answers.Clear();
                    

                }
                _conn.Close();


                foreach (var c in controls)
                {
                    Controls.Add(c);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                _conn.Close();
            }

        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }
    }
}

