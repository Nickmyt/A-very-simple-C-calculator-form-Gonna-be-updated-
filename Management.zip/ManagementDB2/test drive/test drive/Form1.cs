﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test_drive
{
    public partial class Form1 : Form
    {
        private readonly Form2 f2 = new Form2();
        private readonly Form3 f3 = new Form3();
        private readonly Form4 f4 = new Form4();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //In case user presses the exit button
           
            MessageBox.Show(@"Thank you for using our application", 
                            @"Application Closed",
                            MessageBoxButtons.OK, 
                            MessageBoxIcon.Asterisk);
        }

        private void Create_btn_Click(object sender, EventArgs e)
        {
            
            f2.Show();
        }

        private void Select_btn_Click(object sender, EventArgs e)
        {
           Form3 f3 =  new Form3();
            f3.Show();
        }

       

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Help_btn_Click(object sender, EventArgs e)
        {
            f4.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
